<?php

namespace Vendor;

class FooBar
{

}

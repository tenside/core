<?php

namespace Vendor;

class FooBar11 extends FooBar
{

}

<?php

echo 'This is just a fixture.';
